<?php

header('Content-Type: application/json; charset=utf-8');

$ruta = '/home/oicnjgmy/firebase/asistencia-nordictech-firebase-adminsdk-fbsvc-d9e549c4bd.json';

$resultado = [
    'php_version' => PHP_VERSION,
    'curl_instalado' => extension_loaded('curl'),
    'openssl_instalado' => extension_loaded('openssl'),
    'json_instalado' => extension_loaded('json'),
    'archivo_existe' => is_file($ruta),
    'archivo_legible' => is_readable($ruta),
    'json_valido' => false,
    'campos_firebase' => false
];

if ($resultado['archivo_legible']) {
    $contenido = file_get_contents($ruta);
    $credenciales = json_decode($contenido, true);

    $resultado['json_valido'] =
        json_last_error() === JSON_ERROR_NONE;

    $resultado['campos_firebase'] =
        is_array($credenciales) &&
        !empty($credenciales['project_id']) &&
        !empty($credenciales['client_email']) &&
        !empty($credenciales['private_key']);
}

echo json_encode($resultado, JSON_PRETTY_PRINT);